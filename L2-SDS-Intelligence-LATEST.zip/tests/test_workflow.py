import pytest
from unittest.mock import MagicMock, patch
from src.workflow import (
    create_sds_graph,
    decide_action_node,
    search_node,
    route_action,
    perform_verification,
    format_policy_context,
    validate_search_query,
    generate_adaptive_query
)
from src.schema import ActionDecision
from src.state import SDSState

def test_graph_compilation():
    graph = create_sds_graph()
    assert graph is not None
    node_names = list(graph.nodes.keys())
    assert "decide_action" in node_names
    assert "search" in node_names
    assert "rank" in node_names
    assert "fetch" in node_names
    assert "draft" in node_names
    assert "verify" in node_names
    assert "correct" in node_names
    assert "extract_final" in node_names

def test_llm_policy_chooses_search():
    """Test 1: LLM policy receives empty candidate observation and decides SEARCH with targeted search_query."""
    mock_llm = MagicMock()
    mock_structured = MagicMock()
    mock_decision = ActionDecision(
        action="SEARCH",
        search_query="Acetone Sigma-Aldrich English United States SDS PDF",
        reason="No candidates discovered yet. Initiating targeted 4-field search."
    )
    mock_structured.invoke.return_value = mock_decision
    mock_llm.with_structured_output.return_value = mock_structured

    state: SDSState = {
        "messages": [],
        "row_data": {"Product Name": "Acetone", "Product Company Name": "Sigma-Aldrich", "Language": "English", "Country": "United States"},
        "discovered_candidates": [],
        "ranked_candidates": [],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": [],
        "current_search_query": None,
        "action_history": [],
        "next_action": None,
        "iteration_count": 0,
        "retry_count": 0,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "PENDING",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }

    result = decide_action_node(state, llm=mock_llm)
    assert mock_structured.invoke.called
    assert result["next_action"] == "SEARCH"
    assert result["current_search_query"] == "Acetone Sigma-Aldrich English United States SDS PDF"
    assert result["action_history"][-1]["search_query"] == "Acetone Sigma-Aldrich English United States SDS PDF"

def test_search_node_executes_model_selected_query():
    """Test 2: search_node actually executes the model-selected query and stores it in search_queries."""
    state: SDSState = {
        "messages": [],
        "row_data": {"Product Name": "Acetone", "Product Company Name": "Sigma-Aldrich", "Language": "English", "Country": "United States"},
        "discovered_candidates": [],
        "ranked_candidates": [],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": [],
        "current_search_query": "Acetone Sigma-Aldrich English United States SDS PDF",
        "action_history": [{"action": "SEARCH", "search_query": "Acetone Sigma-Aldrich English United States SDS PDF"}],
        "next_action": "SEARCH",
        "iteration_count": 1,
        "retry_count": 0,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "PENDING",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }

    with patch("src.workflow.search_duckduckgo.invoke") as mock_search:
        mock_search.return_value = [
            {"url": "https://sigma.com/acetone.pdf", "title": "Acetone SDS", "body": "Safety Data Sheet"}
        ]
        search_res = search_node(state)
        assert mock_search.called
        # Verify that search_duckduckgo was called with the model-selected query
        called_args = mock_search.call_args[0][0]
        assert called_args["query"] == "Acetone Sigma-Aldrich English United States SDS PDF"
        assert "Acetone Sigma-Aldrich English United States SDS PDF" in search_res["search_queries"]
        assert len(search_res["discovered_candidates"]) == 1
        assert search_res["discovered_candidates"][0]["source_query"] == "Acetone Sigma-Aldrich English United States SDS PDF"

def test_llm_policy_search_observation_chooses_fetch():
    """Test 3: LLM policy receives search candidates observation and chooses FETCH on target candidate."""
    mock_llm = MagicMock()
    mock_structured = MagicMock()
    mock_decision = ActionDecision(
        action="FETCH",
        target_url="https://sigma.com/acetone_sds.pdf",
        reason="Discovered candidate is a direct PDF from manufacturer matching product identity."
    )
    mock_structured.invoke.return_value = mock_decision
    mock_llm.with_structured_output.return_value = mock_structured

    state: SDSState = {
        "messages": [],
        "row_data": {"Product Name": "Acetone", "Product Company Name": "Sigma-Aldrich", "Language": "English", "Country": "United States"},
        "discovered_candidates": [
            {"url": "https://sigma.com/acetone_sds.pdf", "title": "Acetone SDS", "snippet": "Safety Data Sheet"}
        ],
        "ranked_candidates": [
            {"url": "https://sigma.com/acetone_sds.pdf", "score": 95, "title": "Acetone SDS", "snippet": "Safety Data Sheet"}
        ],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": ["Acetone Sigma-Aldrich SDS"],
        "current_search_query": None,
        "action_history": [{"action": "SEARCH", "reason": "Executed initial search"}],
        "next_action": None,
        "iteration_count": 1,
        "retry_count": 0,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "PENDING",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }

    result = decide_action_node(state, llm=mock_llm)
    assert mock_structured.invoke.called
    assert result["next_action"] == "FETCH"
    assert result["current_candidate_url"] == "https://sigma.com/acetone_sds.pdf"

def test_llm_policy_adaptive_retry_generates_new_query():
    """Test 4: When LLM chooses RETRY with a new search query, it is validated and prevents identical query repetition."""
    mock_llm = MagicMock()
    mock_structured = MagicMock()
    mock_decision = ActionDecision(
        action="RETRY",
        search_query="Acetone 67-64-1 Safety Data Sheet PDF",
        reason="Initial 4-field search yielded no candidates. Retrying with CAS number."
    )
    mock_structured.invoke.return_value = mock_decision
    mock_llm.with_structured_output.return_value = mock_structured

    state: SDSState = {
        "messages": [],
        "row_data": {"Product Name": "Acetone", "Product Company Name": "Sigma-Aldrich", "CAS": "67-64-1", "Language": "English", "Country": "United States"},
        "discovered_candidates": [],
        "ranked_candidates": [],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": ["Acetone Sigma-Aldrich English United States SDS PDF"],
        "current_search_query": None,
        "action_history": [{"action": "SEARCH", "search_query": "Acetone Sigma-Aldrich English United States SDS PDF"}],
        "next_action": None,
        "iteration_count": 1,
        "retry_count": 0,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "PENDING",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }

    result = decide_action_node(state, llm=mock_llm)
    assert mock_structured.invoke.called
    assert result["next_action"] == "SEARCH"
    assert result["current_search_query"] == "Acetone 67-64-1 Safety Data Sheet PDF"
    assert result["retry_count"] == 1

def test_action_prerequisite_guards():
    """Test 5: Explicit action prerequisite guards test suite."""
    row = {"Product Name": "Acetone", "Product Company Name": "Sigma", "Language": "English", "Country": "US"}

    # Guard 1: RANK without discovered candidates redirects to SEARCH
    state_no_cands: SDSState = {
        "messages": [],
        "row_data": row,
        "discovered_candidates": [],
        "ranked_candidates": [],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": [],
        "current_search_query": None,
        "action_history": [],
        "next_action": None,
        "iteration_count": 0,
        "retry_count": 0,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "PENDING",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }
    mock_llm = MagicMock()
    mock_structured = MagicMock()
    mock_structured.invoke.return_value = ActionDecision(action="RANK", reason="Try to rank empty list.")
    mock_llm.with_structured_output.return_value = mock_structured

    res_rank_guard = decide_action_node(state_no_cands, llm=mock_llm)
    assert res_rank_guard["next_action"] == "SEARCH"

    # Guard 2: RETRY without previous attempt redirects to SEARCH
    mock_structured.invoke.return_value = ActionDecision(action="RETRY", reason="Try retry on step 0.")
    res_retry_guard = decide_action_node(state_no_cands, llm=mock_llm)
    assert res_retry_guard["next_action"] == "SEARCH"

    # Guard 3: RETRY with exhausted budget (2/2) routes to FINISH
    state_retry_exhausted = dict(state_no_cands)
    state_retry_exhausted["search_queries"] = ["query 1", "query 2"]
    state_retry_exhausted["retry_count"] = 2
    res_retry_exhausted = decide_action_node(state_retry_exhausted, llm=mock_llm)
    assert res_retry_exhausted["next_action"] == "FINISH"

def test_terminal_path_routes_through_verification():
    """Test 6: Verify route_action sends FINISH to draft and verify rather than bypassing verification."""
    state: SDSState = {
        "messages": [],
        "row_data": {"Product Name": "Acetone", "Product Company Name": "Sigma"},
        "discovered_candidates": [],
        "ranked_candidates": [],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": ["query 1"],
        "current_search_query": None,
        "action_history": [],
        "next_action": "FINISH",
        "iteration_count": 6,
        "retry_count": 2,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "PENDING",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }
    routed_target = route_action(state)
    assert routed_target == "draft"  # Routes to draft -> verify -> extract_final

def test_loop_boundedness_and_iteration_limit():
    state: SDSState = {
        "messages": [],
        "row_data": {},
        "discovered_candidates": [],
        "ranked_candidates": [],
        "fetched_urls": [],
        "successful_fetches": {},
        "failed_fetches": {},
        "current_candidate_url": "",
        "search_queries": [],
        "current_search_query": None,
        "action_history": [],
        "next_action": None,
        "iteration_count": 7,  # Exceeded limit
        "retry_count": 3,
        "draft_decision": None,
        "verification_result": None,
        "final_status": "ERROR",
        "final_url": "",
        "confidence": 0,
        "detailed_reasoning": "",
        "provenance": None,
        "mcp_client": None
    }
    decision = decide_action_node(state)
    assert decision["next_action"] == "FINISH"
