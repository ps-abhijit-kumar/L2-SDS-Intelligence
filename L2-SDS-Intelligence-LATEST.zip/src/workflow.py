import os
import re
import json
import time
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple, Literal

import dotenv
from langgraph.graph import StateGraph, END
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
from langchain_groq import ChatGroq

from src.state import SDSState
from src.schema import (
    SDSValidationResult,
    VerificationResult,
    ActionDecision,
    SDSEvidence,
    ValidStatus,
    ActionType,
    is_valid_http_url
)
from src.tools import search_duckduckgo, rank_sds_candidates, fetch_document_text
from src.security import safe_fetch_document, SecurityError
from src.sds_parser import (
    parse_sds_document,
    normalize_identifier,
    normalize_text,
    normalize_url
)

dotenv.load_dotenv()
groq_api_key = os.getenv("GROQ_API_KEY")
groq_model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")

def get_llm():
    if groq_api_key and groq_api_key != "your_groq_api_key_here":
        try:
            return ChatGroq(
                temperature=0,
                groq_api_key=groq_api_key,
                model_name=groq_model
            )
        except Exception:
            return None
    return None

# ==============================================================================
# Helper Verification Logic (Independently Testable Verification Core)
# ==============================================================================

def validate_search_query(raw_query: str, row_data: Dict[str, Any]) -> str:
    """
    Validates and sanitizes a model-selected or fallback search query.
    Enforces security bounds (length, control chars) and ensures actionable content.
    """
    row_data = row_data or {}
    prod = str(row_data.get("Product Name") or row_data.get("Product") or "").strip()
    comp = str(row_data.get("Product Company Name") or row_data.get("Company") or "").strip()
    lang = str(row_data.get("Language") or "English").strip()
    country = str(row_data.get("Country") or "").strip()

    if not raw_query or not isinstance(raw_query, str):
        # Construct standard 4-field query as fallback
        query_parts = []
        if prod:
            query_parts.append(f'"{prod}"' if " " in prod else prod)
        if comp:
            query_parts.append(f'"{comp}"' if " " in comp else comp)
        if lang:
            query_parts.append(lang)
        if country:
            query_parts.append(country)
        query_parts.append("SDS PDF Safety Data Sheet")
        return " ".join(query_parts)

    # Sanitize model-selected query
    sanitized = re.sub(r'[\r\n\t\x00-\x1f]', ' ', raw_query).strip()
    sanitized = re.sub(r'\s+', ' ', sanitized)

    if len(sanitized) < 3 or len(sanitized) > 300:
        # Fallback if too short or excessively long
        return f'"{prod}" "{comp}" {lang} {country} SDS PDF'.strip()

    return sanitized

def generate_adaptive_query(row_data: Dict[str, Any], previous_queries: List[str], retry_idx: int) -> str:
    """
    Generates an adaptive search query for RETRY cycles when prior queries fail.
    Dynamically tries part numbers, CAS identifiers, or broadened keyword structures.
    """
    row_data = row_data or {}
    prod = str(row_data.get("Product Name") or row_data.get("Product") or "").strip()
    comp = str(row_data.get("Product Company Name") or row_data.get("Company") or "").strip()
    part = str(row_data.get("Part Number") or "").strip()
    cas = str(row_data.get("CAS") or "").strip()
    lang = str(row_data.get("Language") or "English").strip()
    country = str(row_data.get("Country") or "").strip()

    previous_set = {q.strip().lower() for q in (previous_queries or [])}

    candidates: List[str] = []

    # Strategy 1: Include CAS number or Part number if available
    if cas:
        candidates.append(f'{prod} CAS {cas} Safety Data Sheet PDF'.strip())
        candidates.append(f'{cas} {comp} SDS PDF'.strip())
    if part:
        candidates.append(f'{prod} {part} {comp} SDS PDF'.strip())
        candidates.append(f'{prod} {part} Safety Data Sheet'.strip())

    # Strategy 2: Relax quotes and try alternative manufacturer tokens
    if comp:
        candidates.append(f'{prod} {comp} Safety Data Sheet {country}'.strip())
        candidates.append(f'{prod} {comp} SDS {lang}'.strip())

    # Strategy 3: Pure chemical search with jurisdiction
    candidates.append(f'{prod} Safety Data Sheet {country} {lang} PDF'.strip())
    candidates.append(f'{prod} SDS chemical safety sheet'.strip())

    for cand in candidates:
        if cand.lower() not in previous_set:
            return cand

    return f'{prod} SDS PDF {country} attempt {retry_idx + 1}'.strip()

def perform_verification(
    row_data: Dict[str, Any],
    draft_status: str,
    draft_url: str,
    draft_confidence: int,
    draft_reasoning: str,
    discovered_candidates: List[Dict[str, Any]],
    successful_fetches: Dict[str, Dict[str, Any]],
    failed_fetches: Dict[str, str]
) -> VerificationResult:
    """
    Independent, deterministic & programmatic verification engine.
    Cross-checks the draft decision against ground truth request parameters,
    discovered candidate URLs, and raw fetched document evidence.
    Enforces that BOTH EXACT MATCH and BEST AVAILABLE must have grounded non-empty URLs.
    """
    row_data = row_data or {}
    discovered_candidates = discovered_candidates or []
    successful_fetches = successful_fetches or {}
    failed_fetches = failed_fetches or {}

    req_product = str(row_data.get("Product Name") or row_data.get("Product") or "").strip()
    req_company = str(row_data.get("Product Company Name") or row_data.get("Company") or "").strip()
    req_part_number = str(row_data.get("Part Number") or "").strip()
    req_country = str(row_data.get("Country") or "").strip()
    req_language = str(row_data.get("Language") or "English").strip()

    norm_req_prod = normalize_text(req_product)
    norm_req_comp = normalize_text(req_company)
    norm_req_part = normalize_identifier(req_part_number)

    issues: List[str] = []
    corrections: Dict[str, Any] = {}

    clean_draft_url = draft_url.strip() if draft_url else ""
    norm_draft_url = normalize_url(clean_draft_url)

    # 1. Provenance & Grounding Verification (Priority 4)
    discovered_urls = {normalize_url(c.get("url", "")) for c in discovered_candidates if c.get("url")}

    if clean_draft_url:
        is_discovered = norm_draft_url in discovered_urls
        fetched_evidence_dict = None
        for fetched_url_key, ev in successful_fetches.items():
            if normalize_url(fetched_url_key) == norm_draft_url:
                fetched_evidence_dict = ev
                break

        if not is_discovered:
            issues.append(f"Grounding Failure: Selected URL '{clean_draft_url}' was not discovered in search results.")

        if not fetched_evidence_dict:
            issues.append(f"Grounding Failure: Selected URL '{clean_draft_url}' was not successfully fetched and verified.")
    else:
        fetched_evidence_dict = None

    # Enforce Phase 6 Rule: Both EXACT MATCH and BEST AVAILABLE must have grounded, non-empty final URL
    if draft_status in ["EXACT MATCH", "BEST AVAILABLE"]:
        if not clean_draft_url:
            issues.append(f"Invalid State: {draft_status} verdict with empty URL.")
            corrections["final_status"] = "NEEDS REVIEW"
            corrections["final_url"] = ""
            corrections["confidence"] = 0
        elif issues:
            corrections["final_status"] = "NEEDS REVIEW"
            corrections["final_url"] = ""
            corrections["confidence"] = min(30, draft_confidence)

    # 2. Document Content & Evidence Verification
    product_match = False
    manufacturer_match = False
    part_number_match = None
    jurisdiction_match = None

    if fetched_evidence_dict and draft_status in ["EXACT MATCH", "BEST AVAILABLE"]:
        if isinstance(fetched_evidence_dict, dict):
            dict_copy = dict(fetched_evidence_dict)
            if "url" not in dict_copy:
                dict_copy["url"] = clean_draft_url
            evidence = SDSEvidence(**dict_copy)
        else:
            evidence = fetched_evidence_dict

        if not evidence.is_sds:
            issues.append("Document Authenticity Issue: Document lacks standard GHS/OSHA SDS headers.")
            corrections["final_status"] = "NEEDS REVIEW"
            corrections["final_url"] = ""
            corrections["confidence"] = min(20, draft_confidence)

        evidence_snippet = (evidence.raw_snippet + " " + " ".join(evidence.sections.values())).lower()
        prod_tokens = norm_req_prod.split()
        if prod_tokens:
            matching_tokens = sum(1 for tok in prod_tokens if tok in evidence_snippet or tok in clean_draft_url.lower())
            if matching_tokens / len(prod_tokens) >= 0.4:
                product_match = True
            else:
                issues.append(f"Product Mismatch: Evidence does not sufficiently reference '{req_product}'.")

        comp_clean = re.sub(r'[^a-z0-9]', '', norm_req_comp)
        if comp_clean and (comp_clean in clean_draft_url.lower() or comp_clean in evidence_snippet):
            manufacturer_match = True
        elif not norm_req_comp:
            manufacturer_match = True
        else:
            issues.append(f"Manufacturer Mismatch: Evidence does not confirm manufacturer '{req_company}'.")

        if norm_req_part:
            found_parts_norm = [normalize_identifier(p) for p in evidence.part_numbers]
            if norm_req_part in found_parts_norm or norm_req_part in normalize_identifier(evidence_snippet):
                part_number_match = True
            else:
                part_number_match = False
                issues.append(f"Part Number Discrepancy: Part number '{req_part_number}' not verified in document.")

        if req_country:
            if evidence.country and evidence.country.lower() in req_country.lower():
                jurisdiction_match = True
            else:
                jurisdiction_match = False

    # 3. Status & Confidence Adjustment / Downgrading Logic
    final_status: ValidStatus = draft_status if draft_status in ["EXACT MATCH", "BEST AVAILABLE", "NEEDS REVIEW"] else "NEEDS REVIEW"
    final_url: str = clean_draft_url
    confidence: int = max(0, min(100, draft_confidence))

    if "final_status" in corrections:
        final_status = corrections["final_status"]
    if "final_url" in corrections:
        final_url = corrections["final_url"]
    if "confidence" in corrections:
        confidence = corrections["confidence"]

    # Check if candidate is direct PDF vs landing page
    is_pdf = clean_draft_url.lower().split('?')[0].endswith('.pdf') or (fetched_evidence_dict and isinstance(fetched_evidence_dict, dict) and fetched_evidence_dict.get("url_type") == "pdf")
    url_type = "pdf" if is_pdf else "landing_page"

    if not is_pdf and clean_draft_url:
        if final_status == "EXACT MATCH":
            final_status = "BEST AVAILABLE"
            confidence = min(70, confidence)
            issues.append("Document is an SDS Landing/Download Page rather than direct PDF. Direct PDF requires manual download.")

    if final_status == "EXACT MATCH":
        if not product_match or not manufacturer_match:
            if product_match and not manufacturer_match:
                final_status = "BEST AVAILABLE"
                confidence = min(75, confidence)
                issues.append("Downgraded EXACT MATCH -> BEST AVAILABLE due to unconfirmed manufacturer.")
            else:
                final_status = "NEEDS REVIEW"
                final_url = ""
                confidence = min(40, confidence)
                issues.append("Downgraded EXACT MATCH -> NEEDS REVIEW due to product/evidence mismatch.")

    if final_status == "BEST AVAILABLE":
        if not final_url or not product_match:
            final_status = "NEEDS REVIEW"
            final_url = ""
            confidence = min(30, confidence)
            issues.append("Downgraded BEST AVAILABLE -> NEEDS REVIEW: lacks grounded URL or product match.")

    if final_status == "EXACT MATCH" and confidence < 50:
        final_status = "NEEDS REVIEW"
        issues.append("Downgraded EXACT MATCH -> NEEDS REVIEW due to confidence < 50.")

    if final_status == "NEEDS REVIEW":
        final_url = ""

    reasoning_parts = []
    if final_status == "EXACT MATCH":
        reasoning_parts.append(f"Verified EXACT MATCH for '{req_product}' from {req_company or 'manufacturer'}.")
        if part_number_match:
            reasoning_parts.append(f"Part number {req_part_number} confirmed.")
        reasoning_parts.append("Direct SDS PDF document validated with authentic GHS safety sections.")
    elif final_status == "BEST AVAILABLE":
        if url_type == "landing_page":
            reasoning_parts.append(f"Legitimate SDS landing/download page retrieved for '{req_product}'. Direct PDF can be downloaded from manufacturer portal.")
        else:
            reasoning_parts.append(f"BEST AVAILABLE SDS retrieved for '{req_product}'.")
        if not manufacturer_match and req_company:
            reasoning_parts.append(f"Note: Candidate provides chemical specification but manufacturer '{req_company}' could not be definitively confirmed.")
        else:
            reasoning_parts.append("Matches chemical profile with minor jurisdiction or variant differences.")
    else:
        reasoning_parts.append("Flagged for human compliance review (NEEDS REVIEW).")
        if issues:
            reasoning_parts.append(f"Reason: {'; '.join(issues[:2])}.")
        else:
            reasoning_parts.append("No conclusive safety data sheet meeting exact compliance standards was found.")

    final_reasoning = " ".join(reasoning_parts)
    if len(final_reasoning) < 5:
        final_reasoning = "Document verification completed according to compliance requirements."

    approved = len(issues) == 0 and final_status == draft_status and final_url == draft_url

    return VerificationResult(
        approved=approved,
        issues=issues,
        corrections=corrections,
        evidence_sufficient=bool(fetched_evidence_dict or final_status == "NEEDS REVIEW"),
        final_status=final_status,
        final_url=final_url,
        url_type=url_type if final_url else None,
        confidence=confidence,
        reasoning=final_reasoning,
        product_match=product_match,
        manufacturer_match=manufacturer_match,
        part_number_match=part_number_match,
        jurisdiction_match=jurisdiction_match,
        required_additional_evidence=["section_1_identification"] if not product_match and final_status != "NEEDS REVIEW" else []
    )

# ==============================================================================
# Graph Nodes & Action Policy Engine
# ==============================================================================

POLICY_SYSTEM_PROMPT = """You are the policy reasoning agent for Safety Data Sheet (SDS) discovery, retrieval, and verification.
Your role is to analyze the target chemical request, available candidate URLs, fetched document evidence, tool observations, and past action history to select the next discrete action.

Permitted Actions:
- SEARCH: Execute web search for candidate SDS URLs. When selecting SEARCH, provide a targeted model-selected 'search_query' matching the chemical request.
- RANK: Rank discovered candidate URLs by relevance to product, manufacturer, and jurisdiction. (Prerequisite: discovered candidates exist).
- FETCH: Download and parse document text from a specific candidate URL. (Provide target_url matching one of the unvisited discovered candidate URLs).
- RETRY: Attempt an adaptive alternative search query or alternative candidate when prior attempts fail. When selecting RETRY, provide a NEW adaptive 'search_query' (incorporating CAS number, catalog identifier, or alternative synonyms) or an unvisited candidate 'target_url'. Do NOT repeat the exact same search query.
- FINISH: Conclude the retrieval workflow when sufficient matching SDS evidence has been gathered or when candidates/retries are exhausted.

Reasoning Rules:
1. If no candidates have been discovered, select SEARCH with a targeted query.
2. If candidates have been discovered but not yet ranked, select RANK.
3. If ranked candidates exist and unvisited candidates remain, select FETCH with the top unvisited target_url.
4. If a fetched document is a valid SDS matching the target product and manufacturer, select FINISH to proceed to independent verification.
5. If a fetched candidate fails or is not an SDS, check remaining candidates: select FETCH for the next candidate, or RETRY with an adaptive search query if candidates are exhausted.
6. If the iteration budget is reached or candidates and retries are exhausted, select FINISH.
7. Always provide a clear, concise justification in 'reason'.
"""

def format_policy_context(state: SDSState) -> str:
    row = state.get("row_data") or {}
    prod = str(row.get("Product Name") or row.get("Product") or "").strip()
    comp = str(row.get("Product Company Name") or row.get("Company") or "").strip()
    lang = str(row.get("Language") or "English").strip()
    country = str(row.get("Country") or "").strip()
    part = str(row.get("Part Number") or "").strip()
    cas = str(row.get("CAS") or "").strip()

    iteration = state.get("iteration_count", 0) + 1
    retry_count = state.get("retry_count", 0)
    discovered = state.get("discovered_candidates") or []
    ranked = state.get("ranked_candidates") or []
    fetched = list(state.get("fetched_urls") or [])
    successful = state.get("successful_fetches") or {}
    failed = state.get("failed_fetches") or {}
    search_queries = list(state.get("search_queries") or [])
    action_history = state.get("action_history") or []
    messages = state.get("messages") or []

    unvisited = [c for c in (ranked or discovered) if c.get("url") and c.get("url") not in fetched]

    evidence_lines = []
    for url, ev in successful.items():
        is_sds = ev.get("is_sds", False)
        cas_nums = ev.get("cas_numbers", [])
        parts = ev.get("part_numbers", [])
        sections = list(ev.get("sections", {}).keys())
        url_type = ev.get("url_type", "pdf")
        doc_lang = ev.get("language", "")
        doc_country = ev.get("country", "")
        evidence_lines.append(
            f"- URL: {url} | Type: {url_type} | Is SDS: {is_sds} | CAS: {cas_nums[:3]} | Parts: {parts[:3]} | Lang: {doc_lang} | Country: {doc_country} | Sections: {len(sections)}"
        )

    failure_lines = [f"- URL: {url} | Error: {err}" for url, err in failed.items()]

    executed_queries_lines = [
        f"- Attempt {i+1}: '{q}'" for i, q in enumerate(search_queries)
    ]

    recent_actions = [
        f"- Step {i+1}: Action={a.get('action')}, Target={a.get('target_url') or 'N/A'}, Query={a.get('search_query') or 'N/A'}, Reason={a.get('reason')}"
        for i, a in enumerate(action_history[-4:])
    ]

    recent_obs = [
        f"- {m.content}" for m in messages[-4:] if hasattr(m, "content") and m.content
    ]

    return f"""Target Chemical SDS Request:
- Product Name: {prod}
- Manufacturer: {comp}
- Language: {lang}
- Jurisdiction/Country: {country}
- Part / Catalog: {part if part else "None"}
- CAS Number: {cas if cas else "None"}

Current Retrieval State:
- Iteration: {iteration} of 6 maximum
- Retry Count: {retry_count} of 2 maximum
- Discovered Candidates Count: {len(discovered)}
- Ranked Candidates Count: {len(ranked)}
- Unvisited Candidates Remaining: {len(unvisited)}
  Top Unvisited URLs: {[c.get('url') for c in unvisited[:3]]}
- Already Fetched URLs: {fetched}

Executed Search Queries History:
{chr(10).join(executed_queries_lines) if executed_queries_lines else "No search queries executed yet."}

Fetched Document Evidence:
{chr(10).join(evidence_lines) if evidence_lines else "None fetched successfully yet."}

Fetch Failures / Errors:
{chr(10).join(failure_lines) if failure_lines else "None."}

Recent Observations:
{chr(10).join(recent_obs) if recent_obs else "None."}

Recent Action History:
{chr(10).join(recent_actions) if recent_actions else "No previous actions."}

Determine the next ActionDecision (SEARCH, RANK, FETCH, RETRY, FINISH). If SEARCH or RETRY, provide an explicit 'search_query'."""

def decide_action_node(state: SDSState, llm: Optional[Any] = None) -> Dict[str, Any]:
    """
    LLM Policy Engine for Action Selection with Deterministic Action Prerequisite Guards.
    Provides state, candidate evidence, and previous queries to the LLM and validates
    the resulting ActionDecision at the deterministic system safety boundary.
    """
    iteration = state.get("iteration_count", 0) + 1
    retry_count = state.get("retry_count", 0)
    discovered = state.get("discovered_candidates") or []
    ranked = state.get("ranked_candidates") or []
    fetched_urls = list(state.get("fetched_urls") or [])
    successful = state.get("successful_fetches") or {}
    failed = state.get("failed_fetches") or {}
    search_queries = list(state.get("search_queries") or [])
    action_history = list(state.get("action_history") or [])
    draft = state.get("draft_decision")
    verification = state.get("verification_result")
    row = state.get("row_data") or {}

    prod = str(row.get("Product Name") or row.get("Product") or "").strip()
    comp = str(row.get("Product Company Name") or row.get("Company") or "").strip()

    # 1. Deterministic hard budget limit
    if iteration > 6:
        action_entry = {
            "action": "FINISH",
            "reason": "Iteration limit reached. Concluding retrieval for independent verification.",
            "target_url": None,
            "search_query": None,
            "retry_count": retry_count,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        return {
            "next_action": "FINISH",
            "current_search_query": None,
            "iteration_count": iteration,
            "action_history": action_history + [action_entry]
        }

    # 2. Invoke real LLM policy if available
    active_llm = llm or state.get("llm") or get_llm()
    decision: Optional[ActionDecision] = None

    if active_llm is not None:
        try:
            structured_llm = active_llm.with_structured_output(ActionDecision)
            context_prompt = format_policy_context(state)
            messages = [
                SystemMessage(content=POLICY_SYSTEM_PROMPT),
                HumanMessage(content=context_prompt)
            ]
            raw_decision = structured_llm.invoke(messages)
            if isinstance(raw_decision, ActionDecision):
                decision = raw_decision
            elif isinstance(raw_decision, dict):
                decision = ActionDecision(**raw_decision)
        except Exception:
            decision = None

    # 3. Deterministic Action Prerequisite Guard Matrix
    unvisited = [c for c in (ranked or discovered) if c.get("url") and c.get("url") not in fetched_urls]
    discovered_urls = {c.get("url") for c in (ranked or discovered) if c.get("url")}

    if decision is None:
        # Deterministic fallback policy when LLM is unavailable or failed
        if not discovered and len(search_queries) == 0:
            initial_query = validate_search_query("", row)
            decision = ActionDecision(
                action="SEARCH",
                search_query=initial_query,
                reason="Initial state: initiating targeted chemical discovery search."
            )
        elif discovered and not ranked:
            decision = ActionDecision(
                action="RANK",
                reason="Candidates discovered: evaluating deterministic utility ranking."
            )
        elif unvisited and len(fetched_urls) < 3 and not successful and not draft and not verification:
            top_cand = unvisited[0]
            decision = ActionDecision(
                action="FETCH",
                target_url=top_cand.get("url"),
                reason=f"Fetching candidate URL: {top_cand.get('url')}"
            )
        elif (fetched_urls or len(search_queries) > 0) and not draft and not verification and not successful:
            if retry_count < 2:
                if unvisited:
                    next_cand = unvisited[0]
                    decision = ActionDecision(
                        action="RETRY",
                        target_url=next_cand.get("url"),
                        reason=f"Retrying with alternative candidate: {next_cand.get('url')}",
                        retry_count=retry_count + 1
                    )
                else:
                    adaptive_query = generate_adaptive_query(row, search_queries, retry_count)
                    decision = ActionDecision(
                        action="RETRY",
                        search_query=adaptive_query,
                        reason="All discovered candidates exhausted. Retrying with adaptive query.",
                        retry_count=retry_count + 1
                    )
            else:
                decision = ActionDecision(
                    action="FINISH",
                    reason="Candidate attempts and retry budget exhausted. Concluding retrieval for verification."
                )
        elif successful or draft or verification:
            decision = ActionDecision(
                action="FINISH",
                reason="Candidate evidence evaluated. Concluding retrieval for independent verification."
            )
        else:
            decision = ActionDecision(
                action="FINISH",
                reason="Default completion."
            )
    else:
        # Deterministic Action Prerequisite Guard on LLM output
        validated_action = str(decision.action).upper()
        if validated_action not in ["SEARCH", "RANK", "FETCH", "VERIFY", "FINISH", "RETRY", "DRAFT"]:
            validated_action = "FINISH"

        # Guard 1: SEARCH Prerequisite: Valid request identity exists & search budget remains
        if validated_action == "SEARCH":
            if not prod:
                validated_action = "FINISH"
                decision.reason = "Incomplete request identity: missing product name."
            elif len(search_queries) >= 3 and not unvisited:
                validated_action = "FINISH"
                decision.reason = "Maximum search query budget reached."
            else:
                decision.search_query = validate_search_query(decision.search_query or "", row)

        # Guard 2: RANK Prerequisite: Discovered candidates exist
        elif validated_action == "RANK":
            if not discovered:
                if len(search_queries) < 2:
                    validated_action = "SEARCH"
                    decision.search_query = validate_search_query("", row)
                    decision.reason = "Prerequisite guard: No candidates to rank. Redirecting to SEARCH."
                else:
                    validated_action = "FINISH"
                    decision.reason = "Prerequisite guard: No candidates discovered."

        # Guard 3: FETCH Prerequisite: Valid candidate URL exists in discovered candidates
        elif validated_action == "FETCH":
            target_url = str(decision.target_url or "").strip()
            if not target_url or target_url not in discovered_urls or target_url in fetched_urls:
                if unvisited:
                    target_url = unvisited[0].get("url", "")
                    decision.target_url = target_url
                    decision.reason = f"Prerequisite guard: Redirected fetch target to highest unvisited candidate: {target_url}"
                else:
                    if retry_count < 2 and len(search_queries) < 3:
                        validated_action = "RETRY"
                        decision.target_url = None
                        decision.search_query = generate_adaptive_query(row, search_queries, retry_count)
                        decision.reason = "Prerequisite guard: No unvisited candidates remain. Redirecting to adaptive RETRY."
                    else:
                        validated_action = "FINISH"
                        decision.target_url = None
                        decision.reason = "Prerequisite guard: Candidate URLs exhausted. Concluding for verification."

        # Guard 4: RETRY Prerequisite: Previous attempt exists and retry budget remains
        elif validated_action == "RETRY":
            if len(search_queries) == 0 and len(fetched_urls) == 0:
                validated_action = "SEARCH"
                decision.search_query = validate_search_query(decision.search_query or "", row)
                decision.reason = "Prerequisite guard: No previous attempt to retry. Redirecting to SEARCH."
            elif retry_count >= 2:
                validated_action = "FINISH"
                decision.reason = "Prerequisite guard: Maximum retry budget reached (2/2). Finalizing."
            else:
                # If LLM selected a candidate to retry
                if decision.target_url and decision.target_url in discovered_urls and decision.target_url not in fetched_urls:
                    validated_action = "FETCH"
                else:
                    # Adaptive search query
                    query_candidate = decision.search_query or ""
                    clean_query = validate_search_query(query_candidate, row)
                    # Check if query is identical to an already executed query
                    if clean_query in search_queries or clean_query == "":
                        clean_query = generate_adaptive_query(row, search_queries, retry_count)
                    decision.search_query = clean_query
                    validated_action = "SEARCH"

        # Guard 5: VERIFY Prerequisite: Evidence or draft exists
        elif validated_action == "VERIFY":
            validated_action = "FINISH"

        decision.action = validated_action

    # Finalize state mapping
    target_candidate_url = decision.target_url or state.get("current_candidate_url", "")
    new_retry_count = decision.retry_count if decision.retry_count > retry_count else retry_count

    current_search_query = None
    if decision.action == "SEARCH":
        current_search_query = decision.search_query or validate_search_query("", row)
    elif decision.action == "RETRY":
        new_retry_count += 1
        if decision.target_url:
            decision.action = "FETCH"
            target_candidate_url = decision.target_url
        else:
            decision.action = "SEARCH"
            current_search_query = decision.search_query or generate_adaptive_query(row, search_queries, retry_count)

    action_entry = {
        "action": decision.action,
        "reason": decision.reason,
        "target_url": decision.target_url,
        "search_query": decision.search_query or current_search_query,
        "retry_count": new_retry_count,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    return {
        "next_action": decision.action,
        "current_candidate_url": target_candidate_url,
        "current_search_query": current_search_query,
        "iteration_count": iteration,
        "retry_count": new_retry_count,
        "action_history": action_history + [action_entry],
        "messages": [
            AIMessage(content=f"Agent Policy Decision: Action={decision.action}, Query={decision.search_query or 'N/A'}, Target={decision.target_url or 'N/A'}, Reason={decision.reason}")
        ]
    }

def search_node(state: SDSState) -> Dict[str, Any]:
    """
    Executes the validated model-selected search query (or sanitized fallback) via DuckDuckGo.
    Records the executed query in search_queries history for provenance and loop prevention.
    """
    row = state.get("row_data") or {}
    prod = str(row.get("Product Name") or row.get("Product") or "").strip()
    company = str(row.get("Product Company Name") or row.get("Company") or "").strip()
    language = str(row.get("Language") or "").strip()
    country = str(row.get("Country") or "").strip()

    # Guard: If any required SDS identity field is missing, flag as NEEDS REVIEW without fabricating defaults
    if not prod or not company or not language or not country:
        missing_fields = []
        if not prod:
            missing_fields.append("Product Name")
        if not company:
            missing_fields.append("Manufacturer")
        if not language:
            missing_fields.append("Language")
        if not country:
            missing_fields.append("Country/Jurisdiction")
        return {
            "discovered_candidates": [],
            "final_status": "NEEDS REVIEW",
            "final_url": "",
            "confidence": 0,
            "detailed_reasoning": f"Incomplete SDS search identity: missing required field(s): {', '.join(missing_fields)}. Cannot execute verified retrieval without complete request parameters.",
            "next_action": "FINISH",
            "messages": [
                HumanMessage(content=f"Search halted: missing required SDS identity fields ({', '.join(missing_fields)}). Marked as NEEDS REVIEW.")
            ]
        }

    # Model-Selected Search Query Execution (Phase 2 & 3)
    raw_query = state.get("current_search_query")
    if not raw_query and state.get("action_history"):
        latest_action = state.get("action_history")[-1]
        raw_query = latest_action.get("search_query")

    query = validate_search_query(raw_query or "", row)

    results = search_duckduckgo.invoke({"query": query, "max_results": 5})

    existing_discovered = list(state.get("discovered_candidates") or [])
    existing_urls = {c.get("url") for c in existing_discovered if c.get("url")}
    new_discovered = []
    now_str = datetime.now(timezone.utc).isoformat()

    if isinstance(results, list):
        for idx, item in enumerate(results):
            if isinstance(item, dict) and "url" in item:
                cand_url = item["url"]
                if cand_url not in existing_urls:
                    existing_urls.add(cand_url)
                    new_discovered.append({
                        "candidate_id": f"cand_{len(existing_discovered) + idx}",
                        "url": cand_url,
                        "title": item.get("title", ""),
                        "snippet": item.get("snippet", ""),
                        "source_query": query,
                        "discovered_at": now_str
                    })

    all_discovered = existing_discovered + new_discovered
    previous_queries = list(state.get("search_queries") or [])
    all_queries = previous_queries + ([query] if query not in previous_queries else [])

    return {
        "discovered_candidates": all_discovered,
        "search_queries": all_queries,
        "current_search_query": None,
        "messages": [
            HumanMessage(content=f"Search executed with query: '{query}'. Found {len(new_discovered)} new candidates (Total: {len(all_discovered)}).")
        ]
    }

def rank_node(state: SDSState) -> Dict[str, Any]:
    row = state.get("row_data") or {}
    discovered = state.get("discovered_candidates") or []
    prod = str(row.get("Product Name") or row.get("Product") or "").strip()
    company = str(row.get("Product Company Name") or row.get("Company") or "").strip()
    part_num = str(row.get("Part Number") or "").strip()
    country = str(row.get("Country") or "").strip()

    ranked = rank_sds_candidates.invoke({
        "candidates": discovered,
        "target_product": prod,
        "target_company": company,
        "target_part_number": part_num,
        "target_country": country
    })

    top_url = ranked[0]["url"] if ranked else ""

    return {
        "ranked_candidates": ranked,
        "current_candidate_url": top_url,
        "messages": [
            AIMessage(content=f"Ranked {len(ranked)} candidates. Top candidate: {top_url}")
        ]
    }

async def fetch_node(state: SDSState) -> Dict[str, Any]:
    target_url = state.get("current_candidate_url") or ""
    fetched_urls = list(state.get("fetched_urls") or [])
    successful = dict(state.get("successful_fetches") or {})
    failed = dict(state.get("failed_fetches") or {})

    if not target_url:
        return {"messages": [AIMessage(content="No candidate URL available to fetch.")]}

    if target_url not in fetched_urls:
        fetched_urls.append(target_url)

    mcp_client = state.get("mcp_client")
    if mcp_client and hasattr(mcp_client, "inspect_sds_document"):
        try:
            # Genuine MCP tool execution behind the MCP boundary
            evidence_json = await mcp_client.inspect_sds_document(target_url)
            evidence_dict = json.loads(evidence_json) if isinstance(evidence_json, str) else evidence_json
            if isinstance(evidence_dict, dict) and evidence_dict.get("fetched_successfully"):
                successful[target_url] = evidence_dict
                return {
                    "fetched_urls": fetched_urls,
                    "successful_fetches": successful,
                    "current_candidate_url": target_url,
                    "messages": [
                        AIMessage(content=f"[MCP Document Inspection] Retrieved structured evidence for {target_url}. Is SDS: {evidence_dict.get('is_sds')}, CAS: {evidence_dict.get('cas_numbers')}")
                    ]
                }
            else:
                err_msg = (evidence_dict.get("error") if isinstance(evidence_dict, dict) else None) or "Document inspection returned failure."
                failed[target_url] = err_msg
                return {
                    "fetched_urls": fetched_urls,
                    "failed_fetches": failed,
                    "messages": [
                        AIMessage(content=f"[MCP Document Inspection Error] {target_url}: {err_msg}")
                    ]
                }
        except Exception as mcp_err:
            failed[target_url] = f"MCP Error: {str(mcp_err)}"
            return {
                "fetched_urls": fetched_urls,
                "failed_fetches": failed,
                "messages": [AIMessage(content=f"MCP Error on {target_url}: {str(mcp_err)}")]
            }

    # Safe deterministic fallback if MCP client not attached
    try:
        data, content_type, final_url = safe_fetch_document(target_url, timeout=12.0)
        evidence = parse_sds_document(data, content_type, final_url)

        if evidence.fetched_successfully:
            successful[target_url] = evidence.model_dump()
            return {
                "fetched_urls": fetched_urls,
                "successful_fetches": successful,
                "current_candidate_url": target_url,
                "messages": [
                    AIMessage(content=f"Successfully fetched document from {target_url}. Is SDS: {evidence.is_sds}, CAS: {evidence.cas_numbers}")
                ]
            }
        else:
            failed[target_url] = evidence.error or "Failed to parse document."
            return {
                "fetched_urls": fetched_urls,
                "failed_fetches": failed,
                "messages": [
                    AIMessage(content=f"Failed to parse document from {target_url}: {evidence.error}")
                ]
            }

    except SecurityError as sec_err:
        failed[target_url] = f"Security Error: {str(sec_err)}"
        return {
            "fetched_urls": fetched_urls,
            "failed_fetches": failed,
            "messages": [AIMessage(content=f"Security Error on {target_url}: {str(sec_err)}")]
        }
    except Exception as e:
        failed[target_url] = str(e)
        return {
            "fetched_urls": fetched_urls,
            "failed_fetches": failed,
            "messages": [AIMessage(content=f"Fetch error on {target_url}: {str(e)}")]
        }

def draft_decision_node(state: SDSState) -> Dict[str, Any]:
    row = state.get("row_data") or {}
    prod = str(row.get("Product Name") or row.get("Product") or "").strip()
    company = str(row.get("Product Company Name") or row.get("Company") or "").strip()
    part_num = str(row.get("Part Number") or "").strip()
    country = str(row.get("Country") or "").strip()

    successful = state.get("successful_fetches") or {}
    ranked = state.get("ranked_candidates") or []

    # Pick the best fetched candidate
    selected_url = ""
    evidence_dict = None
    cand_score = 50

    for cand in ranked:
        cand_url = cand.get("url", "")
        if cand_url in successful:
            selected_url = cand_url
            evidence_dict = successful[cand_url]
            cand_score = cand.get("score", 50)
            break

    if not evidence_dict and successful:
        selected_url, evidence_dict = next(iter(successful.items()))

    if not evidence_dict or not selected_url:
        draft = {
            "status": "NEEDS REVIEW",
            "confidence": 0,
            "detailed_reasoning": f"No valid document could be retrieved for '{prod}'.",
            "final_url": ""
        }
        return {"draft_decision": draft, "current_candidate_url": ""}

    evidence = SDSEvidence(**evidence_dict)
    full_evidence_text = (evidence.raw_snippet + " " + " ".join(evidence.sections.values())).lower()

    norm_prod = normalize_text(prod)
    norm_comp = normalize_text(company)

    prod_tokens = norm_prod.split()
    prod_match = norm_prod in full_evidence_text or norm_prod in selected_url.lower() or (prod_tokens and any(t in full_evidence_text for t in prod_tokens if len(t) > 3))
    comp_clean = re.sub(r'[^a-z0-9]', '', norm_comp)
    comp_match = comp_clean in selected_url.lower() or comp_clean in full_evidence_text if comp_clean else True

    if evidence.is_sds and prod_match and comp_match:
        status = "EXACT MATCH"
        confidence = max(85, min(98, cand_score))
        reasoning = f"Exact match confirmed for {prod} from {company or 'manufacturer'} with verified SDS safety sections."
    elif evidence.is_sds and prod_match:
        status = "BEST AVAILABLE"
        confidence = max(70, min(84, cand_score))
        reasoning = f"Best available match confirmed for chemical {prod}. Manufacturer specification requires human review."
    else:
        status = "NEEDS REVIEW"
        confidence = max(20, min(50, cand_score))
        reasoning = f"Document retrieved from {selected_url} does not conclusively match requested chemical '{prod}'."

    draft = {
        "status": status,
        "confidence": confidence,
        "detailed_reasoning": reasoning,
        "final_url": selected_url if status != "NEEDS REVIEW" else ""
    }

    return {
        "draft_decision": draft,
        "current_candidate_url": selected_url,
        "messages": [
            AIMessage(content=f"Formulated draft decision: Status={status}, Confidence={confidence}, URL={draft['final_url']}")
        ]
    }

def verify_decision_node(state: SDSState) -> Dict[str, Any]:
    row = state.get("row_data") or {}
    draft = state.get("draft_decision") or {}
    discovered = state.get("discovered_candidates") or []
    successful = state.get("successful_fetches") or {}
    failed = state.get("failed_fetches") or {}

    draft_status = draft.get("status", "NEEDS REVIEW")
    draft_url = draft.get("final_url", "")
    draft_conf = draft.get("confidence", 0)
    draft_reason = draft.get("detailed_reasoning", "No draft reasoning.")

    verification = perform_verification(
        row_data=row,
        draft_status=draft_status,
        draft_url=draft_url,
        draft_confidence=draft_conf,
        draft_reasoning=draft_reason,
        discovered_candidates=discovered,
        successful_fetches=successful,
        failed_fetches=failed
    )

    ver_dict = verification.model_dump()

    return {
        "verification_result": ver_dict,
        "messages": [
            AIMessage(
                content=f"Verification result: approved={verification.approved}, "
                        f"final_status={verification.final_status}, "
                        f"confidence={verification.confidence}, "
                        f"issues={verification.issues}"
            )
        ]
    }

def corrective_action_node(state: SDSState) -> Dict[str, Any]:
    verification = state.get("verification_result") or {}
    final_status = verification.get("final_status", "NEEDS REVIEW")
    final_url = verification.get("final_url", "")
    confidence = verification.get("confidence", 0)
    reasoning = verification.get("reasoning", "Verification adjusted verdict.")

    return {
        "draft_decision": {
            "status": final_status,
            "final_url": final_url,
            "confidence": confidence,
            "detailed_reasoning": reasoning
        }
    }

def extract_final_node(state: SDSState) -> Dict[str, Any]:
    verification = state.get("verification_result") or {}
    draft = state.get("draft_decision") or {}
    row = state.get("row_data") or {}
    discovered = state.get("discovered_candidates") or []
    successful = state.get("successful_fetches") or {}

    status_candidate = verification.get("final_status") or draft.get("status") or "NEEDS REVIEW"
    url_candidate = verification.get("final_url") or draft.get("final_url") or ""
    conf_candidate = verification.get("confidence") if verification.get("confidence") is not None else draft.get("confidence", 0)
    reason_candidate = verification.get("reasoning") or draft.get("detailed_reasoning") or "Verification complete."

    if status_candidate not in ["EXACT MATCH", "BEST AVAILABLE", "NEEDS REVIEW"]:
        status_candidate = "NEEDS REVIEW"

    try:
        conf_int = int(conf_candidate)
        conf_int = max(0, min(100, conf_int))
    except (ValueError, TypeError):
        conf_int = 0

    url_str = str(url_candidate).strip()
    if status_candidate == "EXACT MATCH":
        if not url_str or not is_valid_http_url(url_str) or conf_int < 50:
            status_candidate = "NEEDS REVIEW"
            url_str = ""
            conf_int = min(40, conf_int)
            reason_candidate += " (Downgraded: ungrounded or invalid URL)."
    elif status_candidate == "BEST AVAILABLE":
        if not url_str or not is_valid_http_url(url_str) or conf_int < 30:
            status_candidate = "NEEDS REVIEW"
            url_str = ""
            conf_int = min(30, conf_int)
            reason_candidate += " (Downgraded: ungrounded or missing URL)."

    if status_candidate == "NEEDS REVIEW":
        url_str = ""

    url_type_cand = verification.get("url_type") or ("pdf" if url_str.lower().split("?")[0].endswith(".pdf") else "landing_page")

    provenance = {
        "selected_url": url_str,
        "url_type": url_type_cand if url_str else None,
        "discovered_candidates_count": len(discovered),
        "successful_fetches_count": len(successful),
        "verified_at": datetime.now(timezone.utc).isoformat(),
        "action_sequence": [a.get("action") for a in (state.get("action_history") or [])],
        "executed_queries": state.get("search_queries") or []
    }

    try:
        val_result = SDSValidationResult(
            status=status_candidate,
            confidence=conf_int,
            detailed_reasoning=reason_candidate,
            final_url=url_str,
            url_type=url_type_cand if url_str else None,
            provenance=provenance
        )
        final_status = val_result.status
        confidence = val_result.confidence
        detailed_reasoning = val_result.detailed_reasoning
        final_url = val_result.final_url
        url_type = val_result.url_type
    except Exception as val_err:
        final_status = "NEEDS REVIEW"
        confidence = 0
        final_url = ""
        url_type = None
        detailed_reasoning = f"Output validation adjusted: {str(val_err)}"

    return {
        "final_status": final_status,
        "confidence": confidence,
        "detailed_reasoning": detailed_reasoning,
        "final_url": final_url,
        "url_type": url_type,
        "provenance": provenance
    }

# ==============================================================================
# Conditional Edges
# ==============================================================================

def route_action(state: SDSState) -> str:
    action = state.get("next_action", "FINISH")
    if action == "SEARCH":
        return "search"
    elif action == "RANK":
        return "rank"
    elif action == "FETCH":
        return "fetch"
    elif action == "VERIFY":
        return "verify"
    elif action in ["DRAFT", "FINISH"]:
        return "draft"
    return "draft"

def route_verification(state: SDSState) -> str:
    verification = state.get("verification_result") or {}
    if verification.get("approved"):
        return "extract_final"

    corrections = verification.get("corrections") or {}
    if corrections:
        return "correct"

    return "extract_final"

# ==============================================================================
# Graph Construction
# ==============================================================================

def create_sds_graph():
    workflow = StateGraph(SDSState)

    workflow.add_node("decide_action", decide_action_node)
    workflow.add_node("search", search_node)
    workflow.add_node("rank", rank_node)
    workflow.add_node("fetch", fetch_node)
    workflow.add_node("draft", draft_decision_node)
    workflow.add_node("verify", verify_decision_node)
    workflow.add_node("correct", corrective_action_node)
    workflow.add_node("extract_final", extract_final_node)

    workflow.set_entry_point("decide_action")

    workflow.add_conditional_edges(
        "decide_action",
        route_action,
        {
            "search": "search",
            "rank": "rank",
            "fetch": "fetch",
            "draft": "draft",
            "verify": "verify"
        }
    )

    workflow.add_edge("search", "decide_action")
    workflow.add_edge("rank", "decide_action")
    workflow.add_edge("fetch", "decide_action")
    workflow.add_edge("draft", "verify")

    workflow.add_conditional_edges(
        "verify",
        route_verification,
        {
            "extract_final": "extract_final",
            "correct": "correct"
        }
    )

    workflow.add_edge("correct", "extract_final")
    workflow.add_edge("extract_final", END)

    return workflow.compile()
